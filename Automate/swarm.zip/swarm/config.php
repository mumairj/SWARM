<?php

return array(
    'host' => '127.0.0.1',
    'port' => '5432',
	'dbname' => 'swarm',
	'user' => 'postgres',
	'password' => 'root'
);

?>